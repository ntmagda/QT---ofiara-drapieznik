#ifndef WYKRES_H
#define WYKRES_H

#include <QWidget>
#include "qcustomplot.h"
#include <QVector>

class Wykres : public QWidget
{
    Q_OBJECT
public:
    explicit Wykres(QWidget *parent = 0);



signals:

public slots:

};

#endif // WYKRES_H
